# Changelog

## 1.1.0 — 26 October 2026

- Standardized every paragraph to a shared 16px size across all public and dashboard pages.
- Replaced loose feature columns with aligned, framed cards; added custom images to the main approach section.
- Added full-photo exam pathway cards, image-led inner-page heroes, course imagery, and photographic CTA backgrounds.
- Added 52 unique image placements, including 14 new generated academic photographs.
- Applied consistent bordered action buttons, hover/focus treatments, and aligned course-card metadata and actions.
- Verified 541 paragraph elements on 64 pages, card alignment, hover behavior, the 1,920 responsive cases, existing workflows, and representative automated accessibility checks.

## 1.0.0 — 26 October 2026

- Added 23 public pages with shared header/footer and distinct compositions.
- Added all 41 dashboard pages across student, admin, and instructor roles.
- Added local exam engine, negative marking, timer persistence, automatic expiry submission, answer review, history, and analytics.
- Added local management forms, search, status filters, sorting, pagination, confirmation dialogs, lesson editing, and report export.
- Added light/dark themes, RTL demonstration, responsive navigation, original branding, local assets, and sample downloads.
- Fixed submission cleanup so page navigation does not recreate completed drafts.
- Added static and browser verification, responsive matrix, screenshots, and documentation.

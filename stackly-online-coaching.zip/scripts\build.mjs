import fs from "node:fs";
import path from "node:path";
import { visualFor, saveVisualPlacements } from "./visual-library.mjs";
import {
  courses,
  categories,
  faculty,
  articles,
  sessions,
  rolePages,
  tests,
} from "../assets/js/data.js";

const publicPages = [];
const allPages = [];
const icons = {
  book: "M3 4h7l2 2 2-2h7v15h-7l-2 2-2-2H3z M12 6v15",
  bank: "M3 9l9-6 9 6H3z M5 11v7m5-7v7m4-7v7m5-7v7M3 21h18",
  train: "M6 3h12v14H6z M6 10h12 M9 20l-2 2m8-2 2 2M9 14h.01M15 14h.01",
  atom: "M12 3v18M3 12h18M5 5l14 14M5 19L19 5",
  chart: "M4 3v18h17M8 16l4-6 4 3 5-8",
  check: "M5 12l4 4L20 5",
  clock: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18 M12 7v5l3 2",
  people:
    "M16 21v-4a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v4M9 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6M22 21v-4a4 4 0 0 0-3-4M16 3a3 3 0 0 1 0 6",
  arrow: "M5 12h14M14 7l5 5-5 5",
  menu: "M4 6h16M4 12h16M4 18h16",
  sun: "M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1 1M18 18l1 1M5 19l1-1M18 6l1-1",
  bell: "M6 8a6 6 0 0 1 12 0v8l2 2H4l2-2V8M10 21h4",
  grid: "M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z",
  file: "M5 3h10l4 4v14H5zM14 3v5h5M8 12h8M8 16h8",
  video: "M3 6h12v12H3zM15 10l6-4v12l-6-4",
  award: "M12 3l3 5 6 1-4 4 1 7-6-3-6 3 1-7-4-4 6-1z",
};
export const icon = (name) =>
  `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="${icons[name] || icons.book}"/></svg>`;
const mark =
  '<svg viewBox="0 0 40 40" fill="none" aria-hidden="true"><path d="M5 10l15 7 15-7M5 18l15 7 15-7M5 26l15 7 15-7" stroke="currentColor" stroke-width="4" stroke-linejoin="round"/></svg>';
const brand = (root = "") =>
  `<a class="brand" href="${root}pages/index.html" aria-label="Stackly Coaching home">${mark}<span>stackly<small>LEARN. PRACTICE. ACHIEVE.</small></span></a>`;
const btn = (text, href, kind = "") =>
  `<a class="btn ${kind}" href="${href}">${text} ${icon("arrow")}</a>`;
const link = (text, href) => `<a class="text-link" href="${href}">${text} →</a>`;
const photo = (name, alt, cls = "", eager = false) =>
  `<img src="../assets/images/${name}.webp" alt="${alt}" class="${cls}" width="1000" height="700" ${eager ? 'fetchpriority="high"' : 'loading="lazy"'} decoding="async">`;
const head = (eyebrow, title, description = "", action = "") =>
  `<div class="section-head"><div><span class="eyebrow">${eyebrow}</span><h2>${title}</h2></div>${description ? `<p>${description}</p>` : action}</div>`;
const section = (body, cls = "", id = "") =>
  `<section class="section ${cls}" ${id ? `id="${id}"` : ""}><div class="container">${body}</div></section>`;
const notice = (text) => `<div class="notice">${text}</div>`;
const featureImages = {
  "Teachers who simplify": [
    "approach-teaching",
    "A tutor explaining mathematics to adult learners",
  ],
  "A plan with purpose": ["approach-roadmap", "A student organizing a weekly study timetable"],
  "Practice that informs": ["approach-analysis", "A student reviewing a practice answer sheet"],
  "Support at every step": ["approach-support", "A learner discussing study notes with a mentor"],
};
const feature = (title, desc, i = "book") => {
  const image = featureImages[title];
  return `<article class="feature ${image ? "feature-visual" : ""}">
    ${image ? photo(`enhancements/${image[0]}`, image[1], "feature-media") : ""}
    <div class="feature-body"><div class="icon-box">${icon(i)}</div><h3>${title}</h3><p>${desc}</p></div>
  </article>`;
};
const features = () =>
  `<div class="grid four">${feature("Teachers who simplify", "Learn the why behind every concept with focused, step-by-step explanations.", "people")}${feature("A plan with purpose", "Follow a syllabus-aligned roadmap with manageable weekly milestones.", "book")}${feature("Practice that informs", "Understand your mistakes with topic insights and detailed explanations.", "chart")}${feature("Support at every step", "Keep your notes, practice, lessons, and revision in one learning space.", "check")}</div>`;
const checks = (items) =>
  `<ul class="check-list">${items.map((x) => `<li>${x}</li>`).join("")}</ul>`;
const faqs = (
  items = [
    [
      "Can I try the platform before enrolling?",
      "Yes. Explore the free demonstration mock test and role dashboards. All progress is stored on this browser only.",
    ],
    [
      "What is included with a program?",
      "Each sample program includes a structured syllabus, lesson outlines, practice tests, downloadable notes, and scheduled demo classes.",
    ],
    [
      "Can I learn on my phone?",
      "Yes. Lessons, resources, tests, and analytics adapt to mobile, tablet, and desktop screens.",
    ],
    [
      "Are these real exam results?",
      "No. This template uses clearly labeled fictional results and illustrative student stories. Actual results must be verified before publication.",
    ],
  ],
) =>
  items
    .map(([q, a]) => `<details class="accordion"><summary>${q}</summary><p>${a}</p></details>`)
    .join("");
const stats = () =>
  `<div class="stats">${[
    ["4", "Exam pathways"],
    ["120+", "Sample lesson outlines"],
    ["10", "Free practice questions"],
    ["3", "Demo learning roles"],
  ]
    .map(([n, t]) => `<div class="stat"><b>${n}</b><span>${t}</span></div>`)
    .join("")}</div>`;
let categoryGroup = 0;
const categoriesHTML = () => {
  const group = categoryGroup++;
  return `<div class="grid four category-grid">${categories
    .map((c, i) => {
      const image =
        group === 0
          ? {
              image: `enhancements/path-${["banking", "ssc", "railways", "engineering"][i]}`,
              alt: `Adult aspirants preparing for ${c} examinations`,
            }
          : visualFor(
              `pathway-${group}-${c}`,
              i === 3 ? "science" : i === 2 ? "learning" : "study",
            );
      return `<a class="card category-card category-photo" href="courses.html?category=${c}">
      ${photo(image.image, image.alt, "category-backdrop")}
      <div class="category-content"><span class="icon-box">${icon(["bank", "file", "train", "atom"][i])}</span>
      <h3>${c === "Engineering" ? "Engineering Entrance" : c + " Exams"}</h3>
      <p>${["IBPS • SBI • RBI", "CGL • CHSL • MTS", "NTPC • Group D • ALP", "JEE Main • JEE Advanced"][i]}</p>
      <div class="row between"><span class="category-action">Explore pathway</span>${icon("arrow")}</div></div>
    </a>`;
    })
    .join("")}</div>`;
};
let courseImageIndex = 0;
const courseCard = (c, images = false) => {
  const image = images
    ? { image: c.image, alt: `${c.category} exam aspirant practicing at a study desk` }
    : visualFor(
        `course-card-${courseImageIndex++}-${c.id}`,
        c.id === "engineering" ? "science" : "study",
      );
  return `<article class="card course-card filter-item" data-category="${c.category}" data-search="${c.name.toLowerCase()} ${c.category.toLowerCase()}">
    <div class="course-image-frame">${photo(image.image, image.alt, "card-photo")}</div>
    <div class="card-body"><span class="pill">${c.category.toUpperCase()} · FOUNDATION</span><h3>${c.name}</h3><p>${c.subtitle}</p>
    <div class="card-meta"><span>${c.duration}</span><span>${c.lessons} lessons</span><span>★ ${c.rating} demo</span></div>
    <div class="card-action"><div class="row between"><span class="card-price">₹${c.price.toLocaleString("en-IN")}</span>${link("View course", `course-details.html?course=${c.id}`)}</div></div></div>
  </article>`;
};
const courseGrid = (cover = false) =>
  `<div class="grid four filter-grid">${courses.map((c) => courseCard(c, cover)).join("")}</div><p class="empty" hidden data-empty>No programs match. Try another category or search.</p>`;
const facultyGrid = (portraits = false) =>
  `<div class="grid four filter-grid">${faculty.map((f, i) => `<article class="card filter-item" data-category="${f.subject}" data-search="${f.name.toLowerCase()} ${f.subject.toLowerCase()}">${portraits ? photo(f.image, `Illustrative portrait for fictional faculty ${f.name}`, "portrait") : ""}<div class="card-body"><span class="eyebrow">${f.subject}</span><h3>${f.name}</h3><p>${f.credential}<br>${f.experience} teaching · Demo profile</p><div class="card-action">${link("Meet your mentor", `faculty-details.html?faculty=${f.id}`)}</div></div></article>`).join("")}</div><p class="empty" hidden data-empty>No instructors match this selection.</p>`;
const testimonials = () =>
  `<div class="grid three">${[
    [
      "A clearer plan made my daily preparation feel manageable. The review process helped me see exactly what needed attention.",
      "Priya S.",
      "Banking aspirant",
    ],
    [
      "I stopped rushing through questions and started understanding my mistakes. Each practice session had a purpose.",
      "Karthik R.",
      "SSC aspirant",
    ],
    [
      "Having lessons, notes, and a revision routine together made it easier to stay consistent each week.",
      "Aisha M.",
      "Engineering aspirant",
    ],
  ]
    .map(
      ([q, n, d]) =>
        `<blockquote class="card quote" style="margin:0"><div class="stars" aria-label="5 out of 5 sample rating">★★★★★</div><p>“${q}”</p><footer><strong>${n}</strong><br>${d} · Fictional demo story</footer></blockquote>`,
    )
    .join("")}</div>`;
const steps = () =>
  `<div class="grid four steps">${[
    ["Choose your goal", "Select your exam and find a preparation path that fits."],
    ["Build your foundation", "Follow structured lessons and make each concept your own."],
    ["Practice with purpose", "Apply what you learn in targeted, timed practice tests."],
    ["Reflect and improve", "Review the details, revisit weak topics, and keep moving."],
  ]
    .map(([t, d]) => `<article class="step"><h3>${t}</h3><p>${d}</p></article>`)
    .join("")}</div>`;
const cta = (title = "Your next chapter starts with one step.", image = false) => {
  const background = visualFor(`cta-${title}`, "campus");
  return section(
    `${photo(background.image, background.alt, "cta-backdrop")}<div class="${image ? "split" : "row between"}"><div><span class="eyebrow">PREPARE WITH PURPOSE</span><h2>${title}</h2><p>Find your direction. Build your confidence. Make progress every day.</p><div class="row">${btn("Start your preparation", "register.html", "light")}${link("Talk to an advisor", "contact.html")}</div></div>${image ? photo("enrollment", "Students collaborating in an open learning space", "cta-supporting") : ""}</div>`,
    "cta cta-photo",
  );
};
const filters = (values, placeholder = "Search programs…") =>
  `<div class="filter-bar"><div class="form-field"><label for="catalog-search">Search</label><input type="search" id="catalog-search" data-filter-search placeholder="${placeholder}"></div><div class="form-field"><label for="catalog-category">Category</label><select id="catalog-category" data-filter-category><option value="All">All categories</option>${values.map((v) => `<option>${v}</option>`).join("")}</select></div></div>`;
const schedule = (root = "") =>
  `<div data-schedule>${sessions.map((s) => `<article class="schedule-row"><div class="row"><div class="date-box">${s.month}<b>${s.day}</b></div><div><h3>${s.title}</h3><p>${s.faculty} · ${s.time} · Demo session</p></div></div><button class="btn secondary small" data-register-session="${s.id}">Reserve a seat</button></article>`).join("")}</div>`;
const table = (headers, rows) =>
  `<div class="table-wrap"><table><thead><tr>${headers.map((h) => `<th scope="col">${h}</th>`).join("")}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
const testList = (root = "../dashboard/student/") =>
  `<div class="grid three filter-grid">${tests.map((t) => `<article class="card filter-item" data-category="${t.category}" data-search="${t.name.toLowerCase()}"><div class="card-body"><span class="icon-box">${icon("file")}</span><span class="pill">${t.category === "All" ? "FULL-LENGTH DEMO" : t.category.toUpperCase()}</span><h3 style="margin-top:18px">${t.name}</h3><p>${t.questions.length} questions · ${t.minutes} minutes<br>+2 correct · −0.5 incorrect</p><div class="card-action">${btn("View instructions", `${root}test-instructions.html?test=${t.id}`, "secondary")}</div></div></article>`).join("")}</div><p class="empty" hidden data-empty>No tests match this search.</p>`;
const materials = (root = "../") =>
  `<div class="grid three filter-grid">${[
    ["Quantitative Aptitude", "Percentage essentials", "quant-notes.txt"],
    ["Reasoning", "Patterns & logical thinking", "reasoning-notes.txt"],
    ["English", "Grammar revision checklist", "english-notes.txt"],
    ["General Awareness", "Banking fundamentals", "banking-notes.txt"],
  ]
    .map(
      ([c, t, f]) =>
        `<article class="card filter-item" data-category="${c}" data-search="${c.toLowerCase()} ${t.toLowerCase()}"><div class="card-body"><span class="icon-box">${icon("file")}</span><span class="eyebrow">${c}</span><h3>${t}</h3><p>Original sample notes · TXT · Free download</p><div class="card-action"><a class="btn secondary" href="${root}assets/downloads/${f}" download>Download sample ↓</a></div></div></article>`,
    )
    .join("")}</div><p class="empty" hidden data-empty>No resources match your search.</p>`;
const chartCard = (type, title, subtitle = "Illustrative demo data") =>
  `<article class="card chart-card"><h2>${title}</h2><p>${subtitle}</p><div class="chart-box"><canvas data-chart="${type}" role="img" aria-label="${title}. Data table available below."></canvas></div><details><summary>View accessible data table</summary><div data-chart-table="${type}"></div></details></article>`;

function header(active) {
  const dropdown = (title, items) =>
    `<details><summary>${title}</summary><div class="dropdown">${items.map(([t, h]) => `<a href="${h}" ${h.split("?")[0] === active ? 'aria-current="page"' : ""}>${t}</a>`).join("")}</div></details>`;
  return `<div class="announcement">A little progress, every day. Try your first practice test for free. <a href="mock-tests.html">Start practicing →</a></div><header class="site-header"><div class="container header-inner">${brand("../")}<nav class="nav" id="main-nav" aria-label="Main navigation">${dropdown(
    "Home",
    [
      ["Home Page 1", "index.html"],
      ["Home Page 2", "home-2.html"],
    ],
  )}${dropdown("Courses", [["All Courses", "courses.html"], ...categories.map((c) => [c + " Exams", `courses.html?category=${c}`])])}${[
    ["Faculty", "faculty.html"],
    ["Results", "results.html"],
    ["Fees", "fees.html"],
  ]
    .map(([t, h]) => `<a href="${h}" ${h === active ? 'aria-current="page"' : ""}>${t}</a>`)
    .join("")}${dropdown("Resources", [
    ["Mock Tests", "mock-tests.html"],
    ["Study Materials", "study-materials.html"],
    ["Previous Year Papers", "previous-papers.html"],
    ["Live Classes", "live-classes.html"],
    ["Blog", "blog.html"],
  ])}<a href="about.html" ${active === "about.html" ? 'aria-current="page"' : ""}>About</a><a href="contact.html" ${active === "contact.html" ? 'aria-current="page"' : ""}>Contact</a></nav><div class="header-actions"><button class="icon-button" data-theme-toggle aria-label="Switch color theme">${icon("sun")}</button><a href="login.html">Login</a><a class="btn" href="register.html">Get Started</a><button class="icon-button menu-toggle" aria-label="Toggle navigation" aria-expanded="false" aria-controls="main-nav" data-menu-toggle>${icon("menu")}</button></div></div></header>`;
}
function footer() {
  return `<footer class="site-footer"><div class="container"><div class="footer-grid"><div>${brand("../")}<p>Thoughtful preparation for ambitious minds.<br>One concept, one question, one step forward.</p><div class="socials"><a href="contact.html?channel=linkedin" aria-label="LinkedIn integration information">in</a><a href="contact.html?channel=youtube" aria-label="YouTube integration information">▶</a><a href="contact.html?channel=instagram" aria-label="Instagram integration information">◎</a></div></div><div><h3>Find your course</h3><ul>${categories.map((c) => `<li><a href="courses.html?category=${c}">${c} Exams</a></li>`).join("")}<li><a href="fees.html">Plans & pricing</a></li></ul></div><div><h3>Explore Stackly</h3><ul>${[
    ["About us", "about.html"],
    ["Our faculty", "faculty.html"],
    ["Mock tests", "mock-tests.html"],
    ["Study materials", "study-materials.html"],
    ["Blog & insights", "blog.html"],
    ["Contact us", "contact.html"],
  ]
    .map(([t, h]) => `<li><a href="${h}">${t}</a></li>`)
    .join(
      "",
    )}</ul></div><div><h3>A little inspiration, in your inbox.</h3><p>Get preparation tips and learning updates.<br>Demo subscription; no email is sent.</p><form data-demo-form="newsletter"><label for="footer-email">Email address</label><div class="form-inline"><input type="email" id="footer-email" placeholder="you@example.com" required><button class="btn" type="submit" aria-label="Subscribe to newsletter">→</button></div><div class="form-status" role="status"></div></form><p>hello@stackly.example<br>+91 00000 00000 · Demo contact</p></div></div><div class="footer-bottom row between"><span>© 2026 Stackly Coaching. Educational website template.</span><div class="row"><a href="privacy.html">Privacy Policy</a><a href="terms.html">Terms & Conditions</a><button class="tab" data-dir-toggle>RTL demo</button></div></div></div></footer>`;
}
function documentHTML(
  title,
  body,
  { root = "../", dashboard = false, description, canonical } = {},
) {
  return `<!doctype html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <title>${title} | Stackly Coaching</title>
 <meta name="description" content="${description || `${title}: explore structured exam preparation, purposeful practice, and thoughtful learning at Stackly. Front-end demo template.`}">
 <meta property="og:title" content="${title} | Stackly Coaching">
 <meta property="og:description" content="Prepare with purpose. Explore the Stackly coaching demonstration.">
 <meta property="og:type" content="website">
 <meta property="og:image" content="${root}assets/images/home-one-hero.webp">
 <link rel="canonical" href="https://example.com/stackly/${canonical || ""}">
 ${dashboard ? '<meta name="robots" content="noindex,nofollow">' : ""}
 <link rel="icon" href="${root}assets/images/favicon.svg" type="image/svg+xml">
 <link rel="apple-touch-icon" href="${root}assets/images/apple-touch-icon.png">
 <script src="${root}assets/js/theme.js"></script>
 <link rel="preload" href="${root}assets/fonts/inter-latin.woff2" as="font" type="font/woff2" crossorigin>
 <link rel="stylesheet" href="${root}assets/css/style.css">
 <link rel="stylesheet" href="${root}assets/css/visual-refresh.css">
 <script src="${root}assets/vendor/chart.umd.min.js" defer></script>
 <script type="module" src="${root}assets/js/main.js"></script>
 <script type="application/ld+json">${JSON.stringify({ "@context": "https://schema.org", "@type": "WebPage", name: title, description: "Stackly educational template demonstration" })}</script>
</head>
<body ${dashboard ? 'class="dashboard"' : ""}>
 <a class="skip" href="#main">Skip to main content</a>
 ${body}
 <button class="icon-button back-top" data-back-top aria-label="Back to top">↑</button>
 <div class="toast" role="status" hidden></div>
 <dialog id="app-dialog"><div class="dialog-head"><h2 id="dialog-title">Details</h2><button class="icon-button" data-close-dialog aria-label="Close dialog">×</button></div><div id="dialog-content"></div></dialog>
</body>
</html>`;
}
function writePage(slug, title, content) {
  if (slug === "course-details") {
    const image = visualFor("course-details-hero", "study");
    content = content.replace(
      '<span class="eyebrow" data-course-category>',
      `${photo(image.image, image.alt, "course-detail-photo")}<span class="eyebrow" data-course-category>`,
    );
  }
  const file = `pages/${slug}.html`;
  fs.writeFileSync(
    file,
    documentHTML(title, `${header(slug + ".html")}<main id="main">${content}</main>${footer()}`, {
      canonical: file,
    }),
  );
  publicPages.push({ file, title });
  allPages.push(file);
}
const inner = (title, desc, eyebrow = "YOUR NEXT STEP") => {
  const category = /faculty|teaching|mentor/i.test(title + " " + eyebrow)
    ? "teaching"
    : /live|class/i.test(eyebrow)
      ? "learning"
      : /material|paper|journal|legal/i.test(eyebrow)
        ? "library"
        : /pric|plan/i.test(eyebrow)
          ? "planning"
          : "study";
  const preferred = /faculty/i.test(eyebrow)
    ? "mentor-community"
    : /live/i.test(eyebrow)
      ? "live-learning-room"
      : /material/i.test(eyebrow)
        ? "revision-library"
        : /pricing/i.test(eyebrow)
          ? "preparation-planning"
          : /about/i.test(eyebrow)
            ? "campus-community-new"
            : /course catalog/i.test(eyebrow)
              ? "program-overview"
              : "";
  const image = visualFor(`hero-${eyebrow}-${title}`, category, preferred);
  return `<section class="inner-hero inner-hero-visual"><div class="container inner-hero-grid">
    <div class="inner-hero-copy"><div class="breadcrumb"><a href="index.html">Home</a><span>/</span><span>${eyebrow}</span></div>
    <span class="eyebrow">${eyebrow}</span><h1>${title}</h1><p>${desc}</p></div>
    <div class="inner-hero-media">${photo(image.image, image.alt, "", true)}<span class="image-corner">STACKLY / PREPARE WITH PURPOSE</span></div>
  </div></section>`;
};

/* Home one: exactly ten major content sections. */
writePage(
  "index",
  "Prepare with purpose. Achieve with confidence.",
  `<section class="hero"><div class="container"><div class="split"><div class="hero-copy"><span class="pill">${icon("award")} A BETTER WAY TO PREPARE</span><h1>Big ambitions.<br>Clear direction.<br><em>Your next chapter.</em></h1><p>Expert-led courses, purposeful practice, and a plan that moves you closer to your competitive exam goals.</p><div class="row">${btn("Explore Courses", "courses.html")}${btn("Start a Free Mock Test", "mock-tests.html", "secondary")}</div><div class="row trust"><div class="avatars" aria-hidden="true"><b>AS</b><b>KM</b><b>PN</b><b>RV</b></div><span>Built around your learning journey<br><span class="stars">★★★★★</span> <span>Illustrative student experience</span></span></div></div><div class="hero-image">${photo("home-one-hero", "Two students preparing competitive examinations together in a bright library", "", true)}<div class="floating-note"><span class="icon-box">${icon("chart")}</span><div><strong>Small steps. Real progress.</strong><span class="muted">Learn → Practice → Improve</span></div></div></div></div><div class="exam-strip"><span>PREPARATION FOR<br><b>WHAT COMES NEXT</b></span><b>IBPS & SBI</b><b>SSC CGL & CHSL</b><b>RRB NTPC</b><b>JEE MAIN & ADVANCED</b></div></div></section>` +
    section(
      head(
        "CHOOSE YOUR DIRECTION",
        "One goal. The right pathway.",
        "Focused preparation for the exam and the future you have in mind.",
      ) + categoriesHTML(),
    ) +
    section(
      head(
        "THE STACKLY APPROACH",
        "Clarity at every step.",
        "Everything you need to turn good intentions into a consistent preparation routine.",
      ) + features(),
    ) +
    section(
      head(
        "POPULAR PROGRAMS",
        "Your ambition, well supported.",
        "",
        link("Explore all courses", "courses.html"),
      ) + courseGrid(true),
    ) +
    section(
      head(
        "HOW LEARNING HAPPENS",
        "A little better, every day.",
        "A simple, connected process that keeps you moving forward.",
      ) + steps(),
    ) +
    section(
      `<div class="split">${photo("achievement", "Students celebrating a preparation milestone together", "wide-photo")}<div><span class="eyebrow">PROGRESS WORTH CELEBRATING</span><h2>Every milestone begins<br>with showing up.</h2><p>Preparation is personal. We bring structure to the journey so you can focus on the work that matters.</p>${stats()}<span class="demo-label">Platform sample scope. Student results are fictional demonstrations.</span><p style="margin-top:20px">${link("Explore success stories", "results.html")}</p></div></div>`,
    ) +
    section(
      `<div class="split"><div><span class="eyebrow">PRACTICE WITH PERSPECTIVE</span><h2>More than a score.<br>A way forward.</h2><p>Make every mock test a learning opportunity. See what worked, understand what didn’t, and know where to focus next.</p>${checks(["Timed, exam-style practice", "Clear explanations for every answer", "Topic-level insights and progress history"])}${btn("Try the mock test experience", "mock-tests.html")}</div>${photo("mock-experience", "Study notes and focused practice at a desk", "wide-photo")}</div>`,
    ) +
    section(
      head(
        "MEET YOUR MENTORS",
        "Good teachers make a difference.",
        "",
        link("Explore our faculty", "faculty.html"),
      ) + facultyGrid(true),
    ) +
    section(
      head(
        "THE LEARNER PERSPECTIVE",
        "A more confident kind of preparation.",
        "Fictional demo testimonials illustrating the intended learning experience.",
      ) + testimonials(),
    ) +
    cta("A stronger tomorrow starts with today.", true),
);

/* Home two: a different editorial composition and ten sections. */
writePage(
  "home-2",
  "A thoughtful path to your next opportunity",
  `<section class="editorial-hero"><div class="container split"><div><span class="eyebrow">THE PREPARATION JOURNAL / 2026</span><h1>A thoughtful path<br>to your next<br>opportunity.</h1><p>Make room for your ambitions. Discover structured learning, meaningful practice, and the support to keep going.</p>${btn("Find your preparation path", "courses.html", "light")}<hr class="rule"><p class="small">FOUR EXAM PATHWAYS · ONE CONNECTED LEARNING EXPERIENCE</p></div>${photo("home-two-hero", "Engineering aspirant working independently in a quiet reading room", "", true)}</div></section>` +
    section(head("01 / YOUR DIRECTION", "What are you working toward?") + categoriesHTML()) +
    section(
      head(
        "02 / LEARN TOGETHER",
        "Make space for a live class.",
        "Upcoming illustrative sessions. All times are in India Standard Time.",
      ) + schedule(),
    ) +
    section(
      head("03 / THE PROGRAM EDIT", "Built for the bigger picture.") +
        `<div class="stack">${courses
          .slice(0, 3)
          .map(
            (c, i) =>
              `<article class="schedule-row"><div class="row"><span class="icon-box">${icon(["bank", "file", "train"][i])}</span><div><span class="eyebrow">${c.category} / ${c.duration}</span><h3>${c.name}</h3><p>${c.subtitle}</p></div></div>${btn("View program", `course-details.html?course=${c.id}`, "secondary")}</article>`,
          )
          .join("")}</div>`,
    ) +
    section(
      `<div class="split">${photo("learning-features", "Laptop and notebook for connected online learning", "wide-photo")}<div><span class="eyebrow">04 / A CONNECTED CLASSROOM</span><h2>Learn in a way<br>that stays with you.</h2><p>Pause and reflect. Ask the next question. Turn an explanation into a skill through deliberate practice.</p>${checks(["Lesson notes alongside every concept", "Practice linked to the topics you learn", "An organized space for your preparation"])}${link("Explore the student workspace", "../dashboard/student/index.html")}</div></div>`,
    ) +
    section(
      `<div class="split"><div><span class="eyebrow">05 / YOUR WEEK, CONSIDERED</span><h2>Consistency over intensity.</h2><p>A flexible weekly rhythm gives each part of your preparation the attention it deserves.</p></div><div class="timeline">${[
        ["Monday & Tuesday", "Learn one new concept and work through examples."],
        ["Wednesday & Thursday", "Build fluency with topic-wise practice and notes."],
        ["Friday & Saturday", "Take a timed test and review every response."],
        ["Sunday", "Reflect, revise, and set next week’s priorities."],
      ]
        .map(([t, d]) => `<article><h3>${t}</h3><p>${d}</p></article>`)
        .join("")}</div></div>`,
    ) +
    section(
      head("06 / A CLEARER PICTURE", "Understand your learning patterns.") +
        `<div class="grid two">${chartCard("score", "Your practice, over time")}${chartCard("subjects", "Where your strengths are growing")}</div>`,
    ) +
    section(
      head("07 / PERSONAL MILESTONES", "Progress looks different for everyone.") +
        `<div class="grid two"><article class="quote card"><span class="eyebrow">A FICTIONAL LEARNER JOURNEY</span><h3>From scattered notes to a steady routine.</h3><p>Priya built a weekly plan around shorter, focused study sessions and a consistent mock review habit.</p>${link("Read the learning journeys", "results.html")}</article><div>${stats()}<p class="demo-label">Sample platform scope; no verified exam outcomes are claimed.</p></div></div>`,
    ) +
    section(head("08 / GOOD QUESTIONS", "A few things you might be wondering.") + faqs()) +
    section(
      `<div class="reading" style="text-align:center"><span class="eyebrow">09 / BEGIN WHERE YOU ARE</span><h2>Give your ambition a little structure.</h2><p>Your goals don’t need to feel far away. Start with one concept and one purposeful step.</p>${btn("Create your learning space", "register.html")}</div>`,
    ),
);

writePage(
  "about",
  "A better learning journey, by design",
  inner(
    "A better learning journey, by design.",
    "Stackly brings thoughtful structure to competitive exam preparation, with clarity at the center of every lesson.",
    "ABOUT STACKLY",
  ) +
    section(
      `<div class="split">${photo("our-story", "Students learning together on a university campus", "wide-photo")}<div><span class="eyebrow">OUR STORY</span><h2>Good preparation starts with understanding.</h2><p>This demonstration institute was imagined around a simple idea: learners deserve a clear path through a demanding syllabus.</p><div class="timeline"><article><h3>Start with the learner</h3><p>Understand the goal, available time, and starting point.</p></article><article><h3>Build a connected experience</h3><p>Bring teaching, practice, and reflection into one routine.</p></article></div></div></div>`,
    ) +
    section(
      head("OUR COMPASS", "Purpose in everything we do.") +
        `<div class="grid three">${feature("Our mission", "Make structured, understandable exam preparation accessible to every committed learner.", "book")}${feature("Our vision", "A learning experience that builds independence, confidence, and lasting understanding.", "chart")}${feature("Our values", "Clarity in teaching. Honesty in claims. Respect for every learner’s pace.", "people")}</div>`,
    ) +
    section(head("TEACHING METHODOLOGY", "Understanding before memorization.") + steps()) +
    section(
      head("THE TEMPLATE IN NUMBERS", "A foundation for your institution.") +
        stats() +
        notice(
          "Stackly is a fictional institute in this website template. Replace all sample institute information with your verified history.",
        ),
    ) +
    section(
      head("THE PEOPLE BEHIND THE PURPOSE", "A learning community worth building.") +
        `<div class="grid two">${feature("Academic leadership", "Our demo academic director, Dr. Kavya Rao, coordinates concept-led curricula and consistent assessment. Fictional profile.", "people")}${feature("Join the conversation", "Tell us what you are preparing for and how we can make your journey clearer.", "book")}</div>${btn("Meet our faculty", "faculty.html")} ${btn("Contact the team", "contact.html", "secondary")}`,
    ),
);

writePage(
  "courses",
  "Find your preparation program",
  inner(
    "Your goal. Your preparation path.",
    "Explore focused programs designed to bring clarity, structure, and consistency to your exam preparation.",
    "COURSE CATALOG",
  ) +
    section(head("FIND YOUR FOCUS", "Choose an exam pathway.") + categoriesHTML()) +
    section(
      head("EDITOR’S PICK", "A foundation you can build on.") +
        `<div class="split"><div><span class="pill">BANKING FOUNDATION</span><h2 style="margin-top:20px">One complete plan for IBPS & SBI.</h2><p>A six-month journey through quantitative aptitude, reasoning, English, and banking awareness. Start with the basics and build toward timed practice.</p>${btn("Explore Banking Pro", "course-details.html?course=banking")}</div><div class="card panel">${checks(courses[0].syllabus)}<p class="demo-label">Sample curriculum · ₹4,999 demo price</p></div></div>`,
    ) +
    section(
      head("EXPLORE THE CATALOG", "Find what fits your ambition.") +
        filters(categories) +
        courseGrid(),
    ) +
    section(
      head("COMPARE YOUR OPTIONS", "The essentials, side by side.") +
        table(
          ["Program", "Duration", "Lessons", "Demo fee"],
          courses.map((c) => [
            c.name,
            c.duration,
            c.lessons,
            "₹" + c.price.toLocaleString("en-IN"),
          ]),
        ) +
        `<p class="small muted">Each program includes practice tests, sample resources, and progress tracking.</p>`,
    ) +
    cta("A little guidance goes a long way."),
);

writePage(
  "course-details",
  "Program details & enrollment",
  `<div data-course-details>` +
    section(
      `<div class="breadcrumb"><a href="courses.html">Courses</a><span>/</span><span>Program details</span></div><div class="split"><div><span class="eyebrow" data-course-category>BANKING</span><h1 data-course-name>Banking Pro: IBPS & SBI</h1><p data-course-description>${courses[0].subtitle}</p><p data-course-meta>6 months · 120 lessons · Demo rating 4.8</p></div><aside class="card panel"><span class="eyebrow">YOUR PROGRAM</span><div class="price" data-course-price>₹4,999</div>${checks(["Structured syllabus", "Guided practice & detailed reviews", "Downloadable revision notes"])}<button class="btn" data-enroll>Enroll in this demo course</button><p class="demo-label">No payment is collected. Enrollment is saved on this browser.</p></aside></div>`,
    ) +
    section(
      head("THE LEARNING OUTCOMES", "Understand. Apply. Improve.") +
        `<div class="grid three">${feature("A clear foundation", "Connect core concepts to the question types you will encounter.", "book")}${feature("More deliberate practice", "Build accuracy before increasing your speed under time pressure.", "clock")}${feature("An informed revision plan", "Use your practice results to identify the topics that need another look.", "chart")}</div>`,
    ) +
    section(
      head("THE SYLLABUS", "A roadmap through your preparation.") +
        `<div data-course-syllabus>${faqs(courses[0].syllabus.map((t) => [t, "Concept lessons, worked examples, independent practice, and a focused revision checklist."]))}</div>`,
    ) +
    section(
      head("YOUR ACADEMIC SUPPORT", "Learn from patient, purposeful teachers.") +
        `<div class="grid two">${feature("Concept-led teaching", "Worked examples make the reasoning visible before independent practice begins.", "people")}${feature("A regular review rhythm", "Bring questions to the scheduled demo sessions and revisit lesson summaries.", "check")}</div>${link("Meet the faculty", "faculty.html")}`,
    ) +
    section(
      head("YOUR LEARNING RHYTHM", "A plan that fits your week.") +
        table(
          ["Activity", "Recommended rhythm", "Format"],
          [
            ["Concept lessons", "3 sessions / week", "Lesson outlines"],
            ["Practice", "30 minutes / day", "Timed question sets"],
            ["Revision", "Every Sunday", "Notes & answer analysis"],
          ],
        ),
    ) +
    section(
      head("BEFORE YOU BEGIN", "Make an informed next step.") +
        faqs() +
        notice(
          "Sample learner feedback: “A structured syllabus made my next step clearer.” — Fictional demo learner.",
        ) +
        btn("Create your account", "register.html"),
    ) +
    `</div>`,
);

writePage(
  "faculty",
  "Meet your mentors",
  inner(
    "Good teaching makes room for understanding.",
    "Meet the fictional demo mentors behind our academic approach. Stock portraits illustrate profiles and do not imply endorsement.",
    "OUR FACULTY",
  ) +
    section(
      head("A SHARED APPROACH", "Patient explanations. Purposeful practice.") +
        `<div class="reading"><p>Great teaching helps you understand how an answer is reached. Our sample faculty profiles show how an institute can introduce subject expertise, qualifications, and teaching style with clarity.</p></div>`,
    ) +
    section(
      head("THE FACULTY DIRECTORY", "Find your subject specialist.") +
        filters(
          faculty.map((f) => f.subject),
          "Search a mentor or subject…",
        ) +
        facultyGrid(),
    ) +
    section(
      head("ACROSS THE SYLLABUS", "Depth where it matters.") +
        `<div class="grid four">${faculty.map((f) => feature(f.subject, `${f.credential} · ${f.experience} of fictional teaching experience.`, "book")).join("")}</div>`,
    ) +
    section(
      `<div class="split"><div><span class="eyebrow">OUR TEACHING PHILOSOPHY</span><h2>The best explanation makes the next question easier.</h2></div><div>${checks(["Explain the reasoning, not just the rule", "Use examples that build in difficulty", "Leave room for questions and reflection", "Use assessment to guide the next lesson"])}</div></div>`,
    ) +
    cta("Meet your mentor in a live session."),
);

writePage(
  "faculty-details",
  "Instructor profile",
  inner(
    "Ananya Sharma",
    "A patient, concept-first approach to quantitative aptitude. All faculty identities and credentials are fictional demo content.",
    "FACULTY PROFILE",
  ) +
    section(
      `<div data-faculty-profile><span class="eyebrow" data-faculty-subject>QUANTITATIVE APTITUDE</span><h2 data-faculty-name>Ananya Sharma</h2><p data-faculty-bio>${faculty[0].bio}</p><p data-faculty-credential>${faculty[0].credential} · ${faculty[0].experience} teaching</p></div>`,
    ) +
    section(
      head("THE SUBJECT LENS", "From first principles to fluent practice.") +
        `<div class="grid three">${feature("Conceptual foundations", "Build confidence with a clear explanation and simple examples.", "book")}${feature("Exam applications", "Understand how a concept appears across different question types.", "file")}${feature("Reflective practice", "Use an error log to turn mistakes into useful learning signals.", "chart")}</div>`,
    ) +
    section(
      head("PROGRAMS & CLASSES", "A structured home for your learning.") + courseGrid(false),
    ) +
    section(
      head("LEARN TOGETHER", "Upcoming sessions & learner feedback.") +
        notice(
          "“Clear explanations helped me approach practice more calmly.” — Fictional demo learner.",
        ) +
        schedule(),
    ),
);

writePage(
  "results",
  "Learning journeys & sample results",
  inner(
    "Every journey has its turning points.",
    "Explore illustrative learner journeys and fictional results. These are demonstration profiles, not verified academic outcomes.",
    "SAMPLE RESULTS",
  ) +
    section(
      head("AN HONEST PICTURE", "Illustrative achievements.") +
        notice(
          "All ranks, scores, names, and testimonials below are fictional demo data. No real student achievement is claimed.",
        ) +
        `<div class="stats">${[
          ["86%", "Demo highest score"],
          ["78%", "Demo average accuracy"],
          ["24", "Demo practice attempts"],
          ["12", "Demo weeks of preparation"],
        ]
          .map(([n, t]) => `<div class="stat"><b>${n}</b><span>${t}</span></div>`)
          .join("")}</div>`,
    ) +
    section(
      head("EXAM-WISE JOURNEYS", "Different goals. Shared determination.") + categoriesHTML(),
    ) +
    section(
      head("FICTIONAL STUDENT PROFILES", "The people behind the practice.") +
        table(
          ["Demo learner", "Pathway", "Illustrative result"],
          [
            ["Priya S.", "Banking", "86% practice score"],
            ["Karthik R.", "SSC", "82% practice score"],
            ["Aisha M.", "Engineering", "84% practice score"],
          ],
        ),
    ) +
    section(
      `<div class="split"><div><span class="eyebrow">A FICTIONAL PREPARATION STORY</span><h2>One notebook.<br>A different approach.</h2><p>Karthik began recording why he missed each question. After every mock, he grouped the mistakes by topic and gave the most common ones another focused session.</p></div><div class="timeline"><article><h3>Week 1: Find a starting point</h3><p>A baseline practice test identified the biggest gaps.</p></article><article><h3>Week 6: Build a routine</h3><p>Short daily sessions became easier to maintain.</p></article><article><h3>Week 12: Reflect on progress</h3><p>Consistent review made the next steps clearer.</p></article></div></div>`,
    ) +
    section(
      head("ILLUSTRATIVE LEARNER VOICES", "Confidence grows with understanding.") +
        testimonials() +
        `<div class="row" style="margin-top:30px">${btn("Start your own journey", "register.html")}</div>`,
    ),
);

writePage(
  "fees",
  "Clear plans for purposeful preparation",
  inner(
    "An investment in your next chapter.",
    "Transparent sample pricing. Choose a preparation plan that fits your needs. No real transactions are processed.",
    "PLANS & PRICING",
  ) +
    section(head("CHOOSE YOUR FOCUS", "Four pathways. The same care.") + categoriesHTML()) +
    section(
      head("SIMPLE DEMO PLANS", "Room for every starting point.") +
        `<div class="tabs" aria-label="Pricing period"><button class="tab active" data-price-period="standard" aria-pressed="true">Standard fee</button><button class="tab" data-price-period="scholarship" aria-pressed="false">Demo scholarship · 20% off</button></div><div class="grid three">${[
          ["Essentials", 1999, ["Sample notes library", "Topic-wise practice", "Progress history"]],
          [
            "Complete",
            4999,
            [
              "Everything in Essentials",
              "Complete lesson roadmap",
              "Demo live class reservations",
              "Detailed answer insights",
            ],
          ],
          [
            "Mentored",
            7999,
            [
              "Everything in Complete",
              "Demo mentoring request",
              "Personal study plan outline",
              "Priority demo support",
            ],
          ],
        ]
          .map(
            ([t, p, l], i) =>
              `<article class="card pricing-card ${i === 1 ? "featured" : ""}"><span class="eyebrow">${i === 1 ? "THE COMPLETE EXPERIENCE" : "YOUR PREPARATION"}</span><h3>${t}</h3><div class="price">₹<span data-price="${p}">${p.toLocaleString("en-IN")}</span><small> / program</small></div>${checks(l)}<p class="demo-label">Illustrative fee. No payment collected.</p>${btn("Choose " + t, `register.html?plan=${t}`, i === 1 ? "teal" : "secondary")}</article>`,
          )
          .join("")}</div>`,
    ) +
    section(
      head("THE DETAILS", "Know what your plan includes.") +
        table(
          ["Feature", "Essentials", "Complete", "Mentored"],
          [
            ["Sample study notes", "Included", "Included", "Included"],
            ["Test analytics", "Included", "Included", "Included"],
            ["Lesson roadmap", "—", "Included", "Included"],
            ["Mentoring request", "—", "—", "Demo request"],
          ],
        ),
    ) +
    section(
      `<div class="split"><div><span class="eyebrow">A LITTLE EXTRA SUPPORT</span><h2>Ambition should have room to grow.</h2><p>Use this section to explain your verified scholarship and installment policies. The selector above demonstrates a sample 20% reduction.</p></div><div class="card panel"><h3>Discuss your options</h3><p>Scholarship eligibility and installment terms must be configured by your institution before launch.</p>${btn("Talk to an advisor", "contact.html", "secondary")}</div></div>`,
    ) +
    section(
      head("YOUR PRICING QUESTIONS", "Make the choice with clarity.") +
        faqs([
          [
            "Is the fee charged on this website?",
            "No. All prices are illustrative. Checkout and payment processing require a secure provider integration.",
          ],
          [
            "How does the scholarship preview work?",
            "Select the demo scholarship tab to view a sample 20% discount. This is not an offer or eligibility decision.",
          ],
          [
            "Can I upgrade later?",
            "Your institution can define upgrade, cancellation, and refund terms before production deployment.",
          ],
        ]),
    ),
);

writePage(
  "mock-tests",
  "Practice with perspective",
  inner(
    "A practice test. A clearer next step.",
    "Try a real front-end demonstration with timed questions, negative marking, answer explanations, and local progress history.",
    "MOCK TESTS",
  ) +
    section(
      head("PRACTICE YOUR WAY", "Focused sets or a complete warm-up.") +
        `<div class="grid three">${feature("Subject-wise sets", "Focus on one area and build fluency with shorter practice sessions.", "book")}${feature("Foundation readiness", "A ten-question demonstration across four core subjects.", "file")}${feature("Reflective review", "Review correct answers, explanations, topics, and time spent.", "chart")}</div>`,
    ) +
    section(
      head("TARGET YOUR PRACTICE", "Choose a subject-wise test.") +
        filters(categories, "Search practice tests…") +
        testList(),
    ) +
    section(
      head("THE COMPLETE DEMO", "Start with a foundation readiness test.") +
        notice(
          "10 questions · 10 minutes · +2 correct · −0.5 incorrect · 0 unattempted. Demo content is not an official exam paper.",
        ) +
        btn(
          "Read test instructions",
          "../dashboard/student/test-instructions.html?test=foundation",
        ),
    ) +
    section(
      `<div class="split"><div><span class="eyebrow">THE REVIEW IS PART OF THE PRACTICE</span><h2>Understand what your score is telling you.</h2>${checks(["See correct, incorrect, and unattempted counts", "Explore topic-level performance", "Review time spent on each question"])}</div>${chartCard("accuracy", "A sample answer breakdown")}</div>`,
    ) +
    section(
      head("BEFORE YOU START", "Make your practice count.") +
        faqs([
          [
            "How should I use a mock test?",
            "Choose a quiet time, follow the timer, and reserve time afterward to review every response.",
          ],
          [
            "Where is my attempt stored?",
            "This browser stores demo attempts in localStorage. It is not secure exam storage and is not shared across devices.",
          ],
          [
            "What happens when time runs out?",
            "The test automatically submits your saved responses and calculates the score using the stated negative marking.",
          ],
        ]) +
        btn("Open your student workspace", "../dashboard/student/index.html"),
    ),
);

writePage(
  "study-materials",
  "Notes for a stronger foundation",
  inner(
    "Keep the essentials close.",
    "Original sample notes and revision checklists for deliberate, focused practice. Free downloads are clearly labeled demonstration files.",
    "STUDY MATERIALS",
  ) +
    section(
      head("FIND YOUR NEXT READ", "Search the resource library.") +
        filters(
          ["Quantitative Aptitude", "Reasoning", "English", "General Awareness"],
          "Search notes or subjects…",
        ),
    ) +
    section(head("THE NOTES SHELF", "Useful ideas, ready to revisit.") + materials()) +
    section(head("MAKE IT YOUR OWN", "A more useful revision routine.") + steps()) +
    section(
      head("KEEP LEARNING", "Connect your notes to practice.") +
        `<div class="grid two">${feature("Test the concept", "Use a short practice set to check what you can recall without the notes.", "file")}${feature("Review the reasoning", "Compare your solution with the explanation and add one useful insight to your error log.", "chart")}</div>${btn("Explore practice tests", "mock-tests.html")}`,
    ),
);

writePage(
  "previous-papers",
  "Previous-year paper resource directory",
  inner(
    "Learn from the shape of the exam.",
    "A demonstration paper directory with original sample questions. Downloads are not official previous-year papers.",
    "PAPER DIRECTORY",
  ) +
    section(
      head("SELECT A PATHWAY", "Focus on your exam.") +
        `<div class="tabs" data-paper-tabs>${["All", ...categories].map((c, i) => `<button class="tab ${i === 0 ? "active" : ""}" data-paper-category="${c}" aria-pressed="${i === 0}">${c}</button>`).join("")}</div>`,
    ) +
    section(
      head("YEAR-WISE DIRECTORY", "A structured place for your papers.") +
        `<div data-paper-directory>${table(
          ["Exam", "Year label", "Resource"],
          categories.flatMap((c) =>
            [2025, 2024].map((y) => [
              c,
              y + " · Demo directory entry",
              `<a class="text-link" href="../assets/downloads/sample-paper.txt" download>Original sample only ↓</a>`,
            ]),
          ),
        )}</div>`,
    ) +
    section(
      head("KNOW WHAT YOU DOWNLOAD", "An honest sample, with worked answers.") +
        notice(
          "The downloadable TXT file contains original educational sample questions and an answer key. It does not reproduce or claim to be an official exam paper.",
        ) +
        btn("Download the original sample", "../assets/downloads/sample-paper.txt", "secondary"),
    ) +
    section(
      head("A BETTER WAY TO REVIEW", "Look for patterns, then practice.") +
        `<div class="grid three">${feature("Map the syllabus", "Group question types by the topics they assess.", "book")}${feature("Notice the balance", "Observe the mix of concepts and the time each needs.", "clock")}${feature("Make a revision list", "Turn recurring mistakes into specific practice goals.", "check")}</div>`,
    ),
);

writePage(
  "live-classes",
  "A classroom wherever you learn",
  inner(
    "Learn together. Move forward.",
    "Explore illustrative live sessions led by fictional faculty. Reservation buttons save a browser-local demo registration.",
    "LIVE CLASSES",
  ) +
    section(
      head("ON THE LEARNING CALENDAR", "Your next live session.") +
        notice(
          "Demo dates: 28–30 October 2026. All times are IST (UTC+05:30). No live meeting service is connected.",
        ) +
        schedule(),
    ) +
    section(
      head("YOUR PREFERRED VIEW", "Plan a little learning time.") +
        `<div class="tabs"><button class="tab active" data-schedule-view="list" aria-pressed="true">List view</button><button class="tab" data-schedule-view="calendar" aria-pressed="false">Date cards</button></div><div class="notice">Switch views to rearrange the session schedule above.</div>`,
    ) +
    section(
      `<div class="split">${photo("live-class", "Collaborative group learning in a modern shared classroom", "wide-photo")}<div><span class="eyebrow">THE SESSION SPOTLIGHT</span><h2>Percentages, from the ground up.</h2><p>Join fictional mentor Ananya Sharma for a concept-first workshop. Work through a question, compare approaches, and take a clear practice task away.</p><button class="btn" data-register-session="s1">Reserve a demo seat</button></div></div>`,
    ) +
    section(head("HOW IT WORKS", "A little preparation goes a long way.") + steps()) +
    cta("Make your next question a good one."),
);

const articleCard = (a, withPhoto = true) =>
  `<article class="card filter-item" data-category="${a.category}" data-search="${a.title.toLowerCase()} ${a.excerpt.toLowerCase()}">${withPhoto ? photo(a.image, a.title, "card-photo") : ""}<div class="card-body"><span class="eyebrow">${a.category} / ${a.minutes} MIN READ</span><h3>${a.title}</h3><p>${a.excerpt}</p><div class="card-action">${link("Read the story", `blog-details.html?article=${a.id}`)}</div></div></article>`;
writePage(
  "blog",
  "The preparation journal",
  inner(
    "Ideas for the way you learn.",
    "Thoughtful reading on study habits, exam strategy, and building a preparation routine that lasts.",
    "THE PREPARATION JOURNAL",
  ) +
    section(
      head("THE FEATURED READ", "A little structure changes a lot.") +
        `<div class="split"><div><span class="eyebrow">STRATEGY / 6 MIN READ</span><h2>${articles[0].title}</h2><p>${articles[0].excerpt}</p>${btn("Read the journal", "blog-details.html?article=study-plan")}</div><div class="timeline"><article><h3>Start with your week</h3><p>Work with the time you have, then build from there.</p></article><article><h3>Leave room for revision</h3><p>A plan is only useful when you can return to it.</p></article></div></div>`,
    ) +
    section(
      head("FIND SOMETHING USEFUL", "Explore by topic.") +
        filters(["Strategy", "Quantitative Aptitude", "General Awareness"], "Search the journal…"),
    ) +
    section(
      head("FROM THE JOURNAL", "Read. Reflect. Try something new.") +
        `<div class="grid four filter-grid">${articles.map((a) => articleCard(a)).join("")}</div><p class="empty" hidden data-empty>No articles match your search.</p>`,
    ) +
    section(
      `<div class="reading"><span class="eyebrow">A NOTE FOR YOUR INBOX</span><h2>A little direction, now and then.</h2><p>Demo newsletter. No messages are sent and your address is not uploaded.</p><form data-demo-form="newsletter"><label for="journal-email">Email address</label><div class="form-inline"><input id="journal-email" type="email" required placeholder="you@example.com"><button class="btn">Subscribe</button></div><div class="form-status" role="status"></div></form></div>`,
    ),
);

writePage(
  "blog-details",
  "A practical preparation journal article",
  inner(
    "A study plan you can actually stay with",
    "A practical guide to making your preparation routine clear, realistic, and repeatable.",
    "STRATEGY / JOURNAL",
  ) +
    section(
      photo("article-feature", "A reader selecting a book from a library shelf", "wide-photo") +
        `<p class="small muted" style="margin-top:16px">Stackly Editorial · <span data-article-date>22 October 2026</span> · <span data-article-minutes>6</span> minute read</p>`,
    ) +
    section(
      `<article class="reading" data-article-body><span class="eyebrow">PREPARE WITH PURPOSE</span><h2 data-article-heading>Make the plan fit the life you have.</h2><p data-article-intro>A useful study plan begins with an honest look at your week. Before counting chapters, notice when you have time, energy, and a quiet place to work.</p><h2>01. Choose one clear priority</h2><p>Review the syllabus and take a short baseline test. Pick one topic you can improve this week. Write the outcome in practical terms: “I can solve basic percentage questions without notes.”</p><h2>02. Give practice a place</h2><p>Alternate learning with recall. After a lesson, close your notes and try a small question set. Record the reason for each mistake: a concept gap, a calculation, or a missed instruction.</p><h2>03. Make revision part of the plan</h2><p>Leave one session for reviewing earlier work. Revisit the questions you found difficult and explain the solution aloud. Understanding the reasoning is more useful than recognizing the answer.</p><h2>04. Review the routine itself</h2><p>At the end of the week, notice what you completed and what got in the way. Reduce an unrealistic target, protect a useful study slot, and choose the next small priority. A sustainable plan can change with you.</p><blockquote class="notice">A good week of preparation gives you something specific to understand, practice, and revisit.</blockquote></article>`,
    ) +
    section(
      `<div class="reading"><span class="eyebrow">ABOUT THE AUTHOR</span><h2>Stackly Editorial</h2><p>Original sample educational writing for the Stackly template. General study guidance, not an official examination announcement.</p><button class="btn secondary" data-share>Copy article link</button></div>`,
    ) +
    section(
      head("KEEP READING", "A few more useful ideas.") +
        `<div class="grid three">${articles
          .slice(1)
          .map((a) => articleCard(a, false))
          .join("")}</div>`,
    ),
);

writePage(
  "contact",
  "Let’s find your next step",
  inner(
    "A good question is a good beginning.",
    "Tell us what you are preparing for. This demonstration form validates your details and displays a local confirmation.",
    "CONTACT STACKLY",
  ) +
    section(
      `<div class="grid three">${feature("Write to us", "hello@stackly.example — sample address, not a monitored inbox.", "file")}${feature("Talk it through", "+91 00000 00000 — replace with your institute’s verified number.", "people")}${feature("Find your time", "Demo office hours: Monday–Saturday, 9:00–18:00 IST.", "clock")}</div>`,
    ) +
    section(
      `<div class="split"><div><span class="eyebrow">LET’S TALK ABOUT YOUR GOALS</span><h2>A little guidance can make the next step clearer.</h2><p>Choose your exam interest and leave a message. Nothing is transmitted; connect a form service before production use.</p></div><form data-demo-form="contact"><div class="grid two"><div class="form-field"><label for="contact-name">Full name</label><input id="contact-name" name="name" required minlength="2" autocomplete="name"></div><div class="form-field"><label for="contact-email">Email address</label><input id="contact-email" name="email" type="email" autocomplete="email" required></div></div><div class="form-field"><label for="contact-interest">Exam interest</label><select id="contact-interest" name="interest">${categories.map((c) => `<option>${c}</option>`).join("")}</select></div><div class="form-field"><label for="contact-message">How can we help?</label><textarea id="contact-message" name="message" required minlength="10"></textarea></div><button class="btn">Send demo enquiry</button><div class="form-status" role="status"></div></form></div>`,
    ) +
    section(
      head("OUR LEARNING SPACE", "Put your institute on the map.") +
        `<div class="map-panel"><div class="map-marker">${icon("book")}<h3>Stackly Learning Studio</h3><p>Illustrative location panel.<br>Add your verified address and map embed here.</p></div></div>`,
    ) +
    section(
      head("A LITTLE MORE INFORMATION", "Before you get in touch.") +
        faqs([
          [
            "Will this form send a message?",
            "No. This front-end demo validates the form and shows a confirmation. Connect a backend or form provider before launch.",
          ],
          [
            "Where can I try the learning experience?",
            "Open the Login page and choose student, instructor, or admin demo access.",
          ],
          [
            "Where are the social profiles?",
            "Social buttons currently route to this integration information page. Replace them with verified profile URLs.",
          ],
        ]),
    ),
);

function authForm(type) {
  const register = type === "register",
    forgot = type === "forgot-password";
  return `<form data-auth="${type}">${register ? '<div class="form-field"><label for="full-name">Full name</label><input id="full-name" name="name" autocomplete="name" required minlength="2"></div>' : ""}<div class="form-field"><label for="email">Email address</label><input id="email" name="email" type="email" autocomplete="email" placeholder="you@example.com" required></div>${!forgot ? `<div class="form-field"><label for="password">Password ${register ? "(at least 8 characters, a letter and a number)" : ""}</label><div class="password-wrap"><input id="password" name="password" type="password" minlength="${register ? 8 : 1}" autocomplete="${register ? "new-password" : "current-password"}" required><button type="button" data-password-toggle="password" aria-label="Show password">Show</button></div></div>` : ""}${register ? `<div class="form-field"><label for="confirm-password">Confirm password</label><input id="confirm-password" name="confirm" type="password" autocomplete="new-password" required></div><div class="form-field"><label for="interest">Exam interest</label><select name="interest" id="interest">${categories.map((c) => `<option>${c}</option>`).join("")}</select></div><label class="row"><input type="checkbox" required> I accept the <a class="text-link" href="terms.html">sample terms</a>.</label>` : !forgot ? `<div class="row between" style="margin-bottom:20px"><label class="row"><input name="remember" type="checkbox"> Remember demo role</label><a class="text-link" href="forgot-password.html">Forgot password?</a></div><div class="form-field"><label for="role">Demo workspace</label><select id="role" name="role"><option value="student">Student</option><option value="instructor">Instructor</option><option value="admin">Admin</option></select></div>` : ""}<button class="btn" type="submit">${register ? "Create demo account" : forgot ? "Request demo reset" : "Enter demo workspace"}</button><div class="form-status" role="status"></div></form>`;
}
for (const [slug, title, desc, img] of [
  ["login", "Welcome back.", "A little progress starts with showing up.", "auth-login"],
  [
    "register",
    "Your next chapter starts here.",
    "Create a local demo profile and explore your learning space.",
    "auth-register",
  ],
  [
    "forgot-password",
    "Let’s get you back on track.",
    "Enter your email to preview the password recovery experience.",
    "auth-recovery",
  ],
]) {
  writePage(
    slug,
    title,
    `<section><div class="container auth-layout"><div class="auth-art">${photo(img, "Books and a calm academic study environment")}<span class="eyebrow">PREPARE WITH PURPOSE</span><h2>Good things begin<br>with a clear direction.</h2><p>A connected space for your ambition, practice, and progress.</p></div><div class="auth-panel"><span class="eyebrow">${slug === "login" ? "YOUR LEARNING SPACE" : "A FRESH START"}</span><h1 style="font-size:34px">${title}</h1><p>${desc}</p><p class="demo-label">Demo access only. Passwords are never stored. No real authentication or recovery email service is connected.</p>${authForm(slug)}<hr class="rule"><p class="small">${slug === "register" ? "Already have a profile?" : "New to Stackly?"} <a class="text-link" href="${slug === "register" ? "login" : "register"}.html">${slug === "register" ? "Log in" : "Create a demo account"}</a></p>${slug === "login" ? `<div class="row">${["student", "instructor", "admin"].map((r) => `<button class="tab" data-demo-role="${r}">${r[0].toUpperCase() + r.slice(1)} demo →</button>`).join("")}</div>` : `<a class="text-link" href="login.html">Back to login</a>`}</div></div></section>`,
  );
}
writePage(
  "404",
  "Page not found",
  `<section class="section"><div class="container reading" style="text-align:center"><span class="eyebrow">A SMALL DETOUR</span><div class="error-art" aria-hidden="true">4<span>${icon("book")}</span>4</div><h1>This chapter hasn’t been written.</h1><p>The page you’re looking for may have moved. Let’s get you back to a familiar place.</p><div class="row" style="justify-content:center">${btn("Back to Home", "index.html")}${btn("Explore Courses", "courses.html", "secondary")}</div><hr class="rule">${link("Need a little help? Contact us", "contact.html")}</div></section>`,
);
writePage(
  "coming-soon",
  "A new chapter is on its way",
  `<section class="section"><div class="container reading" style="text-align:center"><span class="eyebrow">SOMETHING THOUGHTFUL IS TAKING SHAPE</span><h1>A new chapter is on its way.</h1><p>We’re preparing the next part of the learning experience. Leave your email to preview our demo interest form.</p><form data-demo-form="newsletter"><label for="coming-email">Email address</label><div class="form-inline"><input id="coming-email" type="email" required placeholder="you@example.com"><button class="btn">Keep me posted</button></div><div class="form-status" role="status"></div></form><p class="demo-label">Demonstration only. No email is sent or uploaded.</p>${link("Explore the current learning experience", "index.html")}</div></section>`,
);
for (const [slug, title, blocks] of [
  [
    "privacy",
    "Privacy Policy",
    [
      [
        "About this sample policy",
        "This document is template content requiring legal customization. Replace it with an accurate policy for your organization, jurisdiction, services, and data practices before production use.",
      ],
      [
        "Information in this demonstration",
        "Profile names, exam interest, local test responses, results, preferences, reservations, and local management edits may be stored in your browser. Passwords are never retained. Forms do not transmit messages.",
      ],
      [
        "Local storage and controls",
        "Theme and layout choices remain on this browser. The student Settings page can clear learning history. Browser settings can remove all local site data. Local storage is not secure or suitable for confidential records.",
      ],
      [
        "Third-party resources",
        "The distributed site includes local fonts, Chart.js, original generated assets, and downloaded illustrative photographs. No analytics or advertising service is configured.",
      ],
      [
        "Production requirements",
        "Document your lawful basis, retention periods, processors, user rights, security controls, children’s data practices, and privacy contact after legal review.",
      ],
    ],
  ],
  [
    "terms",
    "Terms & Conditions",
    [
      [
        "About these sample terms",
        "This is template content requiring legal customization. It is not a complete or jurisdiction-specific agreement. Obtain appropriate review before using it with real learners.",
      ],
      [
        "Demonstration service",
        "Programs, faculty, testimonials, prices, schedules, accounts, transactions, and academic results are illustrative. No real course delivery, payment collection, identity verification, or official assessment is provided.",
      ],
      [
        "Educational use",
        "Original sample questions and notes are supplied for demonstration and practice. They are not official examination materials or a guarantee of selection or academic outcomes.",
      ],
      [
        "Accounts and transactions",
        "Role access is a front-end demonstration. Production authentication, access control, purchases, refunds, and instructor delivery require backend integrations and institution-specific policies.",
      ],
      [
        "Content and acceptable use",
        "Respect source licenses and replace sample claims with verified information. Define your intellectual property terms, conduct standards, limitations, cancellation terms, and dispute process before launch.",
      ],
    ],
  ],
])
  writePage(
    slug,
    title,
    inner(title, "Sample template content requiring legal customization.", "LEGAL / SAMPLE") +
      blocks
        .map(([t, d]) => section(`<div class="reading"><h2>${t}</h2><p>${d}</p></div>`))
        .join(""),
  );

/* Dashboard pages are usable static shells with role-specific content modules. */
for (const [role, items] of Object.entries(rolePages)) {
  for (const [slug, title] of items) {
    const sidebar = `<aside class="sidebar" id="dashboard-nav">${brand("../../")}<div class="sidebar-label">${role} workspace · demo</div><nav aria-label="${role} navigation">${items.map(([s, t], i) => `<a href="${s}.html" ${s === slug ? 'aria-current="page"' : ""}>${icon(["grid", "book", "file", "chart", "clock", "people"][i % 6])}${t}</a>`).join("")}</nav><div class="sidebar-bottom"><nav><a href="../../pages/index.html">${icon("arrow")}Back to website</a><a href="../../pages/login.html" data-logout>${icon("people")}Switch demo role</a></nav></div></aside>`;
    const body = `${sidebar}<div class="dashboard-shell"><header class="dash-top"><div class="row"><button class="icon-button menu-toggle" data-sidebar-toggle aria-label="Toggle dashboard navigation" aria-controls="dashboard-nav" aria-expanded="false">${icon("menu")}</button><span class="small muted">${role[0].toUpperCase() + role.slice(1)} workspace <span class="pill">DEMO</span></span></div><div class="row"><button class="icon-button" data-theme-toggle aria-label="Switch color theme">${icon("sun")}</button><a href="${role === "instructor" ? "announcements" : "notifications"}.html" class="icon-button" aria-label="Notifications">${icon("bell")}</a><a href="profile.html" class="row"><span class="profile-circle">${role === "student" ? "AK" : role === "admin" ? "SR" : "AS"}</span><span class="small profile-name" data-profile-name>${role === "student" ? "Alex Kumar" : role === "admin" ? "Sam Rao" : "Ananya Sharma"}</span></a></div></header><main class="dash-main" id="main" data-dashboard-role="${role}" data-dashboard-page="${slug}"><div class="breadcrumb"><a href="index.html">Workspace</a><span>/</span><span>${title}</span></div><div class="dash-heading row between"><div><h1>${title}</h1><p>Make room for progress. Your ${role} workspace, thoughtfully organized.</p></div><span class="pill">BROWSER-LOCAL DEMONSTRATION</span></div><div id="dashboard-content" aria-live="polite"><p>Preparing your demo workspace…</p></div><p class="demo-label">Fictional demo data · Browser-local storage · No real payments, secure authentication, or live class service.</p></main></div>`;
    const file = `dashboard/${role}/${slug}.html`;
    fs.writeFileSync(
      file,
      documentHTML(title, body, { root: "../../", dashboard: true, canonical: file }),
    );
    allPages.push(file);
  }
}
fs.writeFileSync(
  "index.html",
  '<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Stackly Coaching</title><meta http-equiv="refresh" content="0;url=pages/index.html"><link rel="icon" href="assets/images/favicon.svg"></head><body><a href="pages/index.html">Open Stackly Coaching</a></body></html>\n',
);
fs.writeFileSync(
  "sitemap.xml",
  `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${publicPages
    .filter(
      (p) =>
        !["404", "login", "register", "forgot-password"].some((s) => p.file === `pages/${s}.html`),
    )
    .map((p) => `<url><loc>https://example.com/stackly/${p.file}</loc></url>`)
    .join("")}</urlset>`,
);
fs.writeFileSync(
  "robots.txt",
  "User-agent: *\nAllow: /\nDisallow: /dashboard/\n# Replace the example hostname and repository path before launch.\nSitemap: https://example.com/stackly/sitemap.xml\n",
);
fs.writeFileSync(
  "documentation/pages.json",
  JSON.stringify(
    { public: publicPages, dashboard: allPages.filter((f) => f.startsWith("dashboard")) },
    null,
    2,
  ),
);
console.log(
  `Built ${publicPages.length} public pages and ${allPages.length - publicPages.length} dashboard pages.`,
);
saveVisualPlacements();

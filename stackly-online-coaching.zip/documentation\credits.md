# Asset and dependency credits

- Brand mark, primary logo, dark logo, SVG favicon, PNG favicon variants, Apple icon: original code-native artwork created for Stackly.
- Main and alternative homepage hero photography: generated using the built-in `image_gen` tool, then optimized with ImageMagick. Additional generated assets and full brief summaries are recorded in `image-inventory.json`.
- Other illustrative photographs: downloaded from Unsplash. Exact source URLs are recorded per asset in `image-inventory.json`. [Unsplash License](https://unsplash.com/license) permits free commercial and noncommercial use under its stated conditions. Stock portraits accompany fictional profiles and imply no endorsement.
- Chart.js 4.4.8: [official project](https://github.com/chartjs/Chart.js), MIT License. Local distribution retains its license banner; see `assets/vendor/LICENSE-chartjs.md`.
- Inter: [official project](https://github.com/rsms/inter), SIL Open Font License 1.1. See `assets/fonts/OFL.txt`. Body and heading text use the same family.
- Questions, explanations, study notes, journal articles, SVG artwork, layouts, and UI copy: original sample content for this project.

Reference websites were inspected for layout principles only. No reference-site copy, logos, or photography was reused. Machine-readable inspection results, internal-page discoveries, computed typography and container measurements are in `reference-inspection.json`. Reference screenshots are retained strictly as design-review evidence under `screenshots/reference-*.png`; they are not website assets.
